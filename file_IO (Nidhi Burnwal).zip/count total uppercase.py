#Defining a function to count total uppercase character from a text file
def count_uppercase():
    #Opening the file "ABC.txt" in read mode
    file=open("ABC.txt", "r")
    
    #Initializing a counter for uppercase characters
    uppercase_count = 0
    
    #Iterating over each line in the file
    for line in file:
        #Iterating over each character in the line
        for char in line:
            #Checking if the character is an uppercase letter
            if char.isupper():
                #Incrementing the uppercase counter
                uppercase_count+=1
    
    #Closing the file 
    file.close()
    
    #Printing the total number of uppercase characters
    print("Total uppercase characters:", uppercase_count)

#Calling the function
count_uppercase()



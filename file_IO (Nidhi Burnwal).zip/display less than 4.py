def display_words():
    # Open the file "story.txt" in read mode
    file = open("story.txt", "r")
    
    # Iterate over each line in the file
    for line in file:
        # Split the line into words
        words = line.split()
        
        # Iterate over each word
        for word in words:
            # Check if the word has less than 4 characters
            if len(word) < 4:
                # Print the word
                print(word)
    
    # Close the file when done
    file.close()

# Call the function
display_words()

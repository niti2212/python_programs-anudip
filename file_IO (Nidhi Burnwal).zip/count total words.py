#Defining a function to count total number of words from a text file
def count_words():
    #Opening the file "ABC.txt" in read mode
    file=open("ABC.txt", "r")
    
    #Initializing a counter for words
    word_count=0
    
    #Iterating over each line in the file
    for line in file:
        #Spliting the line into words and increment the counter
        word_count+=len(line.split())
    
    #Closing the file 
    file.close()
    
    #Printing the total number of words
    print("Total words:", word_count)

#Calling the function
count_words()




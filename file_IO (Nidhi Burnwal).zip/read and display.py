# Define a function to read the content from a text file
def read_file():
    # Open the file "ABC.txt" in read mode
    file = open("ABC.txt", "r")
    
    # Iterate over each line in the file
    for line in file:
        # Print each line on the screen, removing leading/trailing whitespace
        print(line.strip())
    
    # Close the file when done
    file.close()

# Call the function
read_file()




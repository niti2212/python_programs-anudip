'''Problem 1 :

 Write a program to take the diamater of a circle as user input

 and calculate and print its area & circumference.'''


# Get the diameter from the user
diameter = float(input("Enter the diameter of the circle: "))

# Calculate the radius
radius = diameter / 2

# Calculate the area 
area = 3.14159 * (radius ** 2)

# Calculate the circumference (C = 2πr)
circumference = 2 * 3.14159 * radius

# Print the results
print(f"Area of the circle: {area:.2f}")
print(f"Circumference of the circle: {circumference:.2f}")

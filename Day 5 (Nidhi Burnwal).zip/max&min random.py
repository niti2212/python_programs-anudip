import random

# Generate 5 random numbers between 1 and 100
random_numbers=[random.randint(1, 100) for _ in range(5)]

# Use max() and min() functions
max_number=max(random_numbers)
min_number=min(random_numbers)

# Print the results
print("Random Numbers:", random_numbers)
print("Maximum:", max_number)
print("Minimum:", min_number)

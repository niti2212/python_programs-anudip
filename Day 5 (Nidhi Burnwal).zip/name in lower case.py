#Accept a name from the user
name=input("Enter your name: ")

# Use the lower() function to convert the name to lower case
lower_case_name=name.lower()

# Display the result
print("Your name in lower case is:",lower_case_name)


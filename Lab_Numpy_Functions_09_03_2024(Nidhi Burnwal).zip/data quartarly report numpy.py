'''Suppose you have a dataset containing monthly sales data for a company, and you
want to split this data into quarterly reports for analysis and reporting purposes.

Input:
monthly_sales = np.array([120, 135, 148, 165, 180, 155, 168, 190, 205, 198, 210, 225])'''


#Importing the NumPy library
import numpy as np

# Monthly sales data for a company
monthly_sales = np.array([120, 135, 148, 165, 180, 155, 168, 190, 205, 198, 210, 225])

# Split the data into quarterly reports
quarterly_sales = np.array([
	# Q1: January, February, March
	monthly_sales[0:3].sum(),
	# Q2: April, May, June
	monthly_sales[3:6].sum(),
	# Q3: July, August, September
	monthly_sales[6:9].sum(),
	# Q4: October, November, December
	monthly_sales[9:12].sum()
])

print(quarterly_sales)

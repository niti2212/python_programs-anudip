'''Suppose you have a dataset containing daily temperature 
readings for a city, and you want to identify days with extreme 
temperature conditions. Find days where the temperature
either exceeded 35 degrees Celsius (hot day) or dropped below 
5 degrees Celsius (cold day).
Input:
temperatures = np.array([32.5, 34.2, 36.8, 29.3, 31.0, 38.7, 23.1, 18.5, 22.8, 37.2])'''

#Importing the NumPy library
import numpy as np

# Input: temperatures
temperatures = np.array([32.5, 34.2, 36.8, 29.3, 31.0, 38.7, 23.1, 18.5, 22.8, 37.2])

# Find hot days (temperature > 35°C)
hot_days = temperatures > 35
print("Hot days:", temperatures[hot_days])

# Find cold days (temperature < 5°C)
cold_days = temperatures < 5
print("Cold days:", temperatures[cold_days])


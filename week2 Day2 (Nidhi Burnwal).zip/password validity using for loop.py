#Accept password input from the user 
'''Length of password at least 8 characters
At least one digit
At least one uppercase letter
At least one lowercase letter
At least one special character (not alphanumeric)'''
password=input("Enter a password: ")

#Initialize a flag to store the validity of the password
valid=True

#Check the length of the password
if len(password)<8:
    print("Password should be at least 8 characters long")
    valid=False

#Check for digits, uppercase and lowercase letters, and special characters
for char in password:
    if char.isdigit():
        break
else:
    print("Password should have at least one digit")
    valid=False

for char in password:
    if char.isupper():
        break
else:
    print("Password should have at least one uppercase letter")
    valid=False

for char in password:
    if char.islower():
        break
else:
    print("Password should have at least one lowercase letter")
    valid=False

for char in password:
    if not char.isalnum():
        break
else:
    print("Password should have at least one special character")
    valid=False

#Print the final validity result
if valid:
    print("Password is valid")
else:
    print("Password is invalid")


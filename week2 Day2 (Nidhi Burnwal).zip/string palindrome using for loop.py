#Accept a string from the user
str=input("Enter a string: ")

#Initialize an empty string to store the reverse
rev=""

#Use for loop to reverse the string
for char in str:
    rev=char+rev

#Check if the reversed string is equal to the original string
if rev==str:
    print("The string is a palindrome")
else:
    print("The string is not a palindrome")

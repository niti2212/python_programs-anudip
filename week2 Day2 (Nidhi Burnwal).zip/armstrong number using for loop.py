#Accept a number from the user
num=int(input("Enter a number: "))

#Initialize a variable to store the sum
sum=0

#Use a for loop to calculate the sum of cubes of each digit
for digit in str(num):
    sum+=int(digit)**len(str(num))

#Check if the sum is equal to the original number
if sum==num:
    print(num, "is an Armstrong number")
else:
    print(num, "is not an Armstrong number")


#Initialize the first two Fibonacci numbers
a,b=0,1

#Use a for loop to generate the Fibonacci series
for i in range(0,10):
    print(a)
    a,b=b,a+b

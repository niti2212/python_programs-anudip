'''Write a Python program to Check if two sets have any elements in common. If

yes, display the common elements.

Input:

set1 = {10, 20, 30, 40, 50}

set2 = {60, 70, 80, 90, 10}

Output:

{10}'''

#Defining the sets
set1={10, 20, 30, 40, 50}
set2={60, 70, 80, 90, 10}

#Using the intersection() method to find common elements
common_elements=set1.intersection(set2)

#Checking if there are any common elements
if common_elements:
    print("The sets have common elements:",common_elements)
else:
    print("The sets do not have any common elements.")

''' Write a Python program to Remove items from set1 that are not common to

both set1 and set2.

Input:

set1 = {10, 20, 30, 40, 50}

set2 = {30, 40, 50, 60, 70}

Output:

{40, 50, 30}'''

#Defining the sets
set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

#Using the intersection method to find common elements
set1 = set1.intersection(set2)

#Printing the updated set1
print(set1)

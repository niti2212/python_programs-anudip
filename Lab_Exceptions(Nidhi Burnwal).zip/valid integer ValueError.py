'''Write a Python program that prompts the user to input an integer and raises a 
ValueError exception if the input is not a valid integer.'''

#Defining a function to get an integer from the user
def get_integer():
    #Loop until a valid integer is entered
    while True:
        try:
            #Getting input an integer from user
            num=int(input("Please enter an integer: "))
            #Return the valid integer
            return num
        except ValueError:
            #Printing an error message if the input is not a valid integer
            print("Error: Invalid integer! Please enter a valid integer.")

#Calling the function to get an integer from the user
num=get_integer()
#Printing the valid integer
print("You entered:",num)


''' Write a Python program that opens a file and handles a FileNotFoundError exception
if the file does not exist.'''

#Defining a function to open a file
def open_file(filename):
    try:
        #Attempting to open the file in read mode
        file=open(filename,'r')
        #Printing a success message
        print(f"File '{filename}' opened successfully!")
        #Returning the file object
        return file
    except FileNotFoundError:
        #Printing an error message if the file does not exist
        print(f"Error: File '{filename}' not found!")

#Calling the function with a filename
filename=input("Enter a filename: ")
file=open_file(filename)

#Checking if the file was opened successfully
if file:
    #Printing the file contents
    print(file.read())
    #Closeing the file
    file.close()

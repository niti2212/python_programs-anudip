'''Write a Python program that prompts the user to input two numbers and raises a
TypeError exception if the inputs are not numerical'''

#Defining a function to get two numbers from the user
def get_numbers():
    while True:
        try:
            #Getting input the first number from user
            num1=float(input("Enter the first number: "))
            #Getting input the second number from user
            num2=float(input("Enter the second number: "))
            #Return the numbers as a tuple
            return num1, num2
        except ValueError:
            #Printing an error message if the inputs are not numerical
            print("Error: Invalid input! Please enter numerical values only.")

#Calling the function to get two numbers from the user
numbers=get_numbers()
print("You entered:",numbers)


'''Write a Python program to handle a ZeroDivisionError exception when dividing a number by zero.'''

#Getting input from user
num1=float(input("Enter the first number: "))
num2=float(input("Enter the second number: "))
    
    #Try to divide num1 by num2
try:
    #Division operation
    result=num1/num2
        
    #Printing the result
    print("The result is:",result)
    
#Catching ZeroDivisionError exception if num2 is zero
except ZeroDivisionError:
    print("Error: Cannot divide by zero!")
except ValueError:
    print("Error: Invalid input! Please enter a number.")

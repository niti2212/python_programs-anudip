'''Write a Python script to concatenate the following dictionaries to create a new one.
Sample Dictionary :
dic1={1:10, 2:20}
dic2={3:30, 4:40}
dic3={5:50,6:60}
Expected Result : {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}'''

#Defining the input dictionaries
dic1={1:10,2:20}  #1st dictionary
dic2={3:30,4:40}  #2nd dictionary
dic3={5:50,6:60}  #3rd dictionary

#Using the ** operator to unpack the dictionaries and create a new one
new_dic={**dic1,**dic2,**dic3}  # Concatenate the dictionaries

#Printing the resulting dictionary
print(new_dic)
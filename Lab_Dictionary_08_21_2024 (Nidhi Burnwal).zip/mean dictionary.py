'''Write a Python program and calculate the mean of the below dictionary.
test_dict = {"A" : 6, "B" : 9, "C" : 5, "D" : 7, "E" : 4}
Output: 6.2

'''

test_dict={"A" : 6, "B" : 9, "C" : 5, "D" : 7, "E" : 4}

#Calculating the sum of the values
sum_values=sum(test_dict.values())

#Calculating the mean
mean=sum_values/len(test_dict)

#printing the mean value
print("Mean:", mean)

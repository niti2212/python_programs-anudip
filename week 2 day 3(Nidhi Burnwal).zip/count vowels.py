# Define the text
text = "Welcome to python Training"

# Convert the text to lowercase
text = text.lower()

# Initialize a dictionary to store the vowel counts
vowel_counts = {"a": 0, "e": 0, "i": 0, "o": 0, "u": 0}

# Count the vowels
for char in text:
    if char in vowel_counts:
        vowel_counts[char] += 1

# Print the vowel counts
for vowel, count in vowel_counts.items():
    print(f"{vowel}: {count}")

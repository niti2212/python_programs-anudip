#define the string
string = "\nBest \nDeeptech \nPython \nTraining\n"
#Use the replace() method to remove newlines
string_without_newlines = string.strip().replace("\n", " ")

#Print the resulting string
print(string_without_newlines)

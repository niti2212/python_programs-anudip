#reverse string using reversed function
string = "Deeptech Python Training"
reversed_string = ' '.join(reversed(string.split()))
#print reverse string
print(reversed_string)


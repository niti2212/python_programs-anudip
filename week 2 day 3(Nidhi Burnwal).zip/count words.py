import re
sentence = "To change the overall look of your document. To change the look available in the gallery"

# Convert the sentence to lower case and split it into words
words = sentence.lower().split()

# Use a dictionary to store the word counts
word_counts = {}

# Iterate over the words and count their occurrences
for word in words:
    # Use regular expression to remove punctuation
    word = re.sub(r'[^\w\s]', '', word)
    if word in word_counts:
        word_counts[word] += 1
    else:
        word_counts[word] = 1

# Print the word counts
for word, count in word_counts.items():
    print(f"{word}: {count}")


#Defining a function to sum the list items
def sum_list(numbers):
    return sum(numbers) ## Using the built-in sum() function to sum the list items

# Define a list of numbers
numbers = [1, 2, 3, 4, 5]

# Call the function and print the result
print("Sum of the list:", sum_list(numbers))

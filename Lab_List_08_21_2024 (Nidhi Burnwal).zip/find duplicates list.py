'''Write a Python program to find duplicate 
values from a list and display those'''

#Defining a list of numbers
numbers=[1,2,3,4,4,5,6,6]

#Creating an empty list to store duplicate numbers
duplicates=[]

#Iterating over the list of numbers
for num in numbers:
	#Checking if the number is already in the duplicates list
	if numbers.count(num) > 1 and num not in duplicates:
		#Adding the number to the duplicates list
		duplicates.append(num)

#Printing the duplicate numbers
print("Duplicate numbers:", duplicates)

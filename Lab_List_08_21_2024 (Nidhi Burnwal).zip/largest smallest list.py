numbers=[15,48,7,21,53,87,34]

#Initializing largest and smallest with the first element
largest=numbers[0]
smallest=numbers[0]

#Iterating over the list
for num in numbers:
    #Checking if num is greater than largest
    if num>largest:
        largest=num
    #Checking if num is smaller than smallest
    if num<smallest:
        smallest=num

print("Largest number:", largest)
print("Smallest number:", smallest)

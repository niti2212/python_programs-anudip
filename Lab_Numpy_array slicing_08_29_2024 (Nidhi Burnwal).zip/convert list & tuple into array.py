'''Write a NumPy program to convert a list and tuple into arrays.
   Input: my_list = [1, 2, 3, 4, 5, 6, 7, 8]
   Input: my_tuple = ([8, 4, 6], [1, 2, 3])'''

#Importing the NumPy library
import numpy as np

#Defining a list
my_list=[1, 2, 3, 4, 5, 6, 7, 8]

#Converting the list to an array
list_array=np.array(my_list)  

#printing the array from list
print("Array from list:")
print(list_array)

#Defining a tuple
my_tuple=([8, 4, 6],[1, 2, 3])

#Converting the tuple to an array
tuple_array=np.array(my_tuple)  

#printing the array from tuple
print("Array from tuple:")
print(tuple_array)


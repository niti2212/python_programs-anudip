'''Write a NumPy program to create an array with values ranging from 12 to 38.'''

#Importing the NumPy library
import numpy as np

#Creating an array with values ranging from 12 to 38
array=np.arange(12,39) 

#Print the resulting array
print(array)  # Print the resulting array


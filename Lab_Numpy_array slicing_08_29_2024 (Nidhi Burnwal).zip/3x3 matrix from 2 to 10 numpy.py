'''Write a NumPy program to create a 3x3 matrix with values ranging from 2 to 10.'''

#Importing the NumPy library
import numpy as np

#Creating a 3x3 matrix with values ranging from 2 to 10
matrix = np.arange(2, 11).reshape(3, 3)

#Print the resulting matrix
print(matrix)



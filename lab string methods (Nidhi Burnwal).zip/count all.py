#Inputing string
input="P@#yn26at^&i5ve"

#Initialize counters for letters, digits, and special symbols
letters=0
digits=0
symbols=0

#Iterate over each character in the input string
for char in input:
    #Check if the character is a letter
    if char.isalpha():
        #Increment the letter counter
        letters+=1
    #Check if the character is a digit
    elif char.isdigit():
        #Increment the digit counter
        digits+=1
    #If the character is neither a letter nor a digit, it's a special symbol
    else:
        #Increment the special symbol counter
        symbols+=1

# Print the results
print("Chars =", letters)
print("Digits =", digits)
print("Symbol =", symbols)


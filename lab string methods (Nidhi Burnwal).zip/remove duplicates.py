#Inputing string
input= "String and String Function"

#Converting the string to a list to remove duplicates
input_list=input.split()

#Initializing an empty list to store the output
output_list=[]

#Iterating over each word in the input list
for word in input_list:
    #Checking if the word is not already in the output list
    if word not in output_list:
        #Append the word to the output list
        output_list.append(word)

#Joining the output list into a string
output_string = ' '.join(output_list)

#Printing the output string
print(output_string)


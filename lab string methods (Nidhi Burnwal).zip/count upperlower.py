#Inputing string
input= "Hell0 W0rld ! 123 * # welcome to pYtHoN"

# Initialize counters for each case
uppercase_count=0  # Count of uppercase letters
lowercase_count=0  # Count of lowercase letters
number_count=0  # Count of numeric values
special_count=0  # Count of special characters

#Iterating over each character in the input string
for char in input:
    #Checking if the character is an uppercase letter
    if char.isupper():  
        uppercase_count+=1
    #Checking if the character is a lowercase letter
    elif char.islower():  
        lowercase_count+=1
    #Checking if the character is a digit
    elif char.isdigit():  
        number_count+=1
    #If the character is not a letter or digit, it's a special character
    else:
        special_count+=1

#Printing the results
print("UpperCase :", uppercase_count)  # Print the count of uppercase letters
print("LowerCase :", lowercase_count)  # Print the count of lowercase letters
print("NumberCase :", number_count)  # Print the count of numeric values
print("SpecialCase :", special_count)  # Print the count of special characters

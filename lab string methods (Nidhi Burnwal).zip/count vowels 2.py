#Inputing string
input= "Welcome to Python Assignment"

#Initializing vowel count
vowel_count=0

#Defining vowels
vowels = 'aeiouAEIOU'

#Iterating over each character in the input string
for char in input:
    #Checking if the character is a vowel
    if char in vowels:
        #Incrementing vowel count
        vowel_count+=1

#Printing the total number of vowels
print("Total vowels are:", vowel_count)


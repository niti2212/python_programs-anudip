def calculate_fare():
    distance = float(input("Enter distance in km: "))

    if distance<=50:
        fare=distance*8
    elif distance<=100:
        fare=distance*10
    else:
        fare=distance*12

    print(f"Fare: Rs. {fare:.2f}")

calculate_fare()


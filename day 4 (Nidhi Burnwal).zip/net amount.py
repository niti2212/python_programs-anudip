def calculate_net_amount():
    prod_code=int(input("Enter product code (1/2/3): "))
    order_amount=float(input("Enter order amount: "))

    if prod_code==1:  # Battery Based Toys
        if order_amount>1000:
            discount=0.10
        else:
            discount=0.00
    elif prod_code==2:  # Key-based Toys
        if order_amount>100:
            discount=0.05
        else:
            discount=0.00
    elif prod_code==3:  # Electrical Charging Based Toys
        if order_amount>500:
            discount=0.10
        else:
            discount=0.00
    else:
        print("Invalid product code!")
        return

    net_amount=order_amount-(order_amount*discount)
    print(f"Net amount to be paid: Rs. {net_amount:.2f}")

calculate_net_amount()
#Python program to find the area of a triangle whose sides are given 

# Get the lengths of the sides from the user
a = float(input("Enter the length of side a: "))
b = float(input("Enter the length of side b: "))
c = float(input("Enter the length of side c: "))

# Calculate the semi-perimeter
s = (a + b + c) / 2

# Calculate the area using Heron's formula
area = (s*(s-a)*(s-b)*(s-c)) ** 0.5

# Print the result
print("The area of the triangle is: ", area)



# Declare two variables
num1 = 10
num2 = 20

# Use ternary operator to print the largest variable
print("num1 is largest" if num1 > num2 else "num2 is largest")

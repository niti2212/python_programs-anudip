# Calculate the multiplication and sum of two numbers

# Get user input
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

# Calculate multiplication
multiplication = num1 * num2

# Calculate sum
sum = num1 + num2

# Print results
print(f"The multiplication of {num1} and {num2} is: {multiplication}")
print(f"The sum of {num1} and {num2} is: {sum}")


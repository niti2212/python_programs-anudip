# Function to convert Fahrenheit to Celsius
def fahren_to_cel(fahrenheit):
    celsius = (fahrenheit - 32) * 5.0/9.0
    return celsius

# Input temperature in Fahrenheit
fahrenheit = float(input("Enter temperature in Fahrenheit: "))

# Convert to Celsius
celsius = fahren_to_cel(fahrenheit)

# Print the result
print(f"{fahrenheit} Fahrenheit is equal to {celsius:.2f} Celsius")

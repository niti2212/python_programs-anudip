'''Convert the below list into numpy array then display the array

Input: my_list = [1, 2, 3, 4, 5]'''

# Import the numpy library and assign it the alias 'np'
import numpy as np

# Define a list
my_list = [1, 2, 3, 4, 5]

# Convert the list into a numpy array
my_array = np.array(my_list)

# Print the original array
print("Original Array:")
print(my_array)



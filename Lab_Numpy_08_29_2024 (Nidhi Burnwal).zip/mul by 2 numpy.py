'''Convert the below list into a numpy array then display the array then
display the first and last index and then multiply each element by 2 and
display the result.
Input: my_list = [1, 2, 3, 4, 5]'''

#Importing the numpy library 
import numpy as np

#Defining a list
my_list=[1,2,3,4,5]

#Converting the list to a numpy array
my_array=np.array(my_list)

#Printing the original array
print("Original Array:")
print(my_array)

#Printing the first index (index 0)
print("First Index:",my_array[0])

#Printing the last index (index -1)
print("Last Index:",my_array[-1])

#Multiplying each element by 2
my_array*=2

#Printing the array after multiplication by 2
print("Array after multiplication by 2:")
print(my_array)

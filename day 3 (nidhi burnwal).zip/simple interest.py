

P = 200  # Principal amount (in Rs)
R = 5   # Rate of interest (in %)
T = 5  # Time (in years)

# Calculate simple interest
SI = (P * R * T) / 100

# Print the result
print("Simple Interest: Rs.", SI)


#Using input() function take one number from the user and using ternary operators check whether the number is even or odd

# Get the number from the user
num = int(input("Enter a number: "))

# Use ternary operator to check whether the number is even or odd
result = "Even" if num % 2 == 0 else "Odd"

# Print the result
print(f"The number {num} is {result}")




# Write a Program to Convert Kilometers to Miles

# Get the distance in kilometers from the user
km = float(input("Enter the distance in kilometers: "))

# Convert kilometers to miles
miles = km * 0.621371

# Print the result
print(f"{km} kilometers is equal to {miles} miles")

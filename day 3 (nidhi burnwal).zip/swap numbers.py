#Using input function take two number and then swap the number

# Get the numbers from the user
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

# Swap the numbers
num1, num2 = num2, num1

# Print the swapped numbers
print("Swapped numbers: ")
print("Number 1: ", num1)
print("Number 2: ", num2)

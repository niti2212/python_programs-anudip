#Accept a number from the user
num=int(input("Enter a number: "))

#Initialize a variable to store the factorial
fac=1

#Use a while loop to calculate the factorial
while num > 0:
    #Multiply the factorial by the current number
    fac*=num
    #Decrement the number
    num-=1

#Print the factorial
print("Factorial:",fac)


#Accept a number from the user
num=int(input("Enter a number: "))

#Initialize an empty variable to store the reverse
rev=0

#Copy the number to a temporary variable
temp=num

#Use a while loop to reverse the number
while temp>0:
    # Get the last digit of the number
    last_digit=temp%10
    # Add the last digit to the reverse
    rev=rev*10+last_digit
    # Remove the last digit from the number
    temp=temp//10

# Check if the reversed number is equal to the original number
if rev==num:
    print(num, "is a palindrome")
else:
    print(num, "is not a palindrome")



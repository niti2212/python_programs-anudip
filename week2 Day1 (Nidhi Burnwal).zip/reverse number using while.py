#Accept a number from the user
num=int(input("Enter a number: "))

#Initialize an empty variable to store the reverse
reverse = 0

#Use while loop to reverse the number
while num!=0:
    #Get the last digit of the number
    last_digit=num%10
    #Add the last digit to the reverse
    reverse=reverse*10+last_digit
    #Remove the last digit from the number
    num=num//10

#Print the reversed number
print("Reversed number:", reverse)


#Initialize a variable to store the sum
total=0

#Use a while loop to accept numbers
i=0
while i>=0:
    #Accept a number from the user
    num=int(input("Enter a number (0 to quit): "))
    
    #Check if the user entered 0
    if num==0:
        #Break the loop
        break
        
    #Add the number to the total
    total+=num
    i+=1

#Print the sum of all the numbers
print("Sum of all numbers:", total)
